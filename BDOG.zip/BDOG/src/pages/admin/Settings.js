import React from 'react'
import AdminSettings from '../../Components/AdminSettings'

const Settings = () => {
  return (
   <AdminSettings/>
  )
}

export default Settings